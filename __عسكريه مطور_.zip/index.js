const fs = require('fs');
const Discord = require('discord.js')
const app = require("express")();

app.get("/", (req, res) => {
  res.send("Hello Word")
})

app.listen(3000, () => {
  console.log("im online on port 3000")
})
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection:', reason);
});

const client = new Discord.Client({
  allowedMentions: { parse: ['roles'], repliedUser: false },
  ws: { properties: { $browser: 'Discord iOS' } },
  messageCacheMaxSize: 999999,
  intents: [Discord.Intents.FLAGS.GUILDS, Discord.Intents.FLAGS.GUILD_MEMBERS, Discord.Intents.FLAGS.GUILD_BANS, Discord.Intents.FLAGS.GUILD_EMOJIS_AND_STICKERS, Discord.Intents.FLAGS.GUILD_INTEGRATIONS, Discord.Intents.FLAGS.GUILD_WEBHOOKS, Discord.Intents.FLAGS.GUILD_INVITES, Discord.Intents.FLAGS.GUILD_VOICE_STATES, Discord.Intents.FLAGS.GUILD_PRESENCES, Discord.Intents.FLAGS.GUILD_MESSAGES, Discord.Intents.FLAGS.GUILD_MESSAGE_REACTIONS, Discord.Intents.FLAGS.GUILD_MESSAGE_TYPING, Discord.Intents.FLAGS.DIRECT_MESSAGES, Discord.Intents.FLAGS.DIRECT_MESSAGE_REACTIONS, Discord.Intents.FLAGS.DIRECT_MESSAGE_TYPING
  ],
  partials: ['MESSAGE', 'CHANNEL', 'REACTION'],
  allowedMentions: {
    parse: ["everyone", "roles", "users"],
    repliedUser: true
  },
  repliedUser: true
});
const prefix = "="
const { Intents, MessageActionRow, MessagePayload, MessageSelectMenu, Modal, MessageEmbed, MessageButton, MessageAttachment, Permissions, TextInputComponent } = require('discord.js');
////////////

client.on('ready', () => {
  console.log(`Logged in as ${client.user.tag}!`);


});
const snow999 = "1191087403503472710"//اللوق حق النقاط
const targetRoleId = ["1135338059437703198","1135340959417245819"]//الي يقدر يرسل رسائل الامبيد
const staffpo = ["1135338059437703198","1135340959417245819","1135521093843697685"]//الي يقدر يزيد نقاط
    const mama = "1153642573383094282"; // روم البلاغات
const astlim = "1135444205863452742"//الي يقدر يستلم البلاغات
const line = "https://media.discordapp.net/attachments/1135396850661335061/1191088970503827546/462857978870104066.gif?ex=65a42b0b&is=6591b60b&hm=a29f3ed89562759a944fb2b39323c89a0e6e077c111d0f8d208a1f60b678f23b&"//خطك
const channelkshf = "1179838443770105926"//شات كشف النقاط
const color = "#150c62"
const snow97 = ""//ايموجي الصح
const snow56 = ""//ايموجي الخطأ 
const snowpolsicon = ""//ايموجي الشرطة
const snowpolspoints = ""//ايموجي كشف نقاط الشرطة
const snowpolspoints2 = ""//ايموجي اضافة النقاط للعسكر
const iconperson = ""//ايموجي الاعضاء
const Listreports = ""//ايموجي قائمة البلاغات 
const Operationscenter = ""//ايموجي مركز العمليات
const iconThanks = ""//ايموجي الشكر على النقاط وكذا
const Listerror = ""//ايموجي القائمة الخاطئة
const Warning = ""//ايموجي التحذير 

const db = require('pro.db')
client.on('messageCreate', async message => {
  if (message.content === '=help') {
 if (!message.member.roles.cache.some(role => targetRoleId.includes(role.id))) return;


    const welcomeEmbed = new MessageEmbed()
      .setTitle('Commands Help')
      .setDescription(`**
• =help 
\`\`\`لعرض قائمة ب اوامر البوت\`\`\`
• #مركز العمليات
\`\`\`لارسال امبيد تسجيل الدخول، تسجيل الخروج، كشف المباشرين\`\`\`
• #البلاغات 
\`\`\`لارسال امبيد البلاغات الخاصة بالمواطنين\`\`\`
• =نقطة+  
\`\`\`لاضافة نقطة لعضو معين\`\`\`
• =نقطة-
\`\`\`لإزالة نقطة من عضو معين\`\`\`
• =نقاطي
\`\`\`للكشف عن نقاطك\`\`\`
• =كشف 
\`\`\`لكشف نقاط عضو معين\`\`\`
• =تصفير-النقاط 
\`\`\`لتصفير جميع النقاط العسكرية\`\`\`**`)
      .setColor(color);


    message.channel.send({
      embeds: [welcomeEmbed],
    });
  }
});
client.on('messageCreate', async (message) => {

  if (message.content === '#مركز العمليات') {
    
if (!message.member.roles.cache.some(role => targetRoleId.includes(role.id)))  return;
  
    const embed = new MessageEmbed()

      .setDescription(`** > مركز العمليات | ${Operationscenter} 

• لتسجيل الدخول يرجى ضغط زر تسجيل الدخول ${snow97} 

• لتسجيل الخروج يرجى ضغط زر تسجيل خروج ${snow56}
• لكشف المباشرين يرجى ضغط كشف المباشرين **`)
      .setColor(color)
    const button = new MessageButton()

      .setCustomId('myButton506')
.setLabel('تسجيل دخول')
      .setEmoji("1128104503049207888")
      .setStyle("SECONDARY");



    const button1 = new MessageButton()

      .setCustomId('myButton1')
.setLabel('تسجيل خروج')       .setEmoji("1128103894254362644")  
      .setStyle("SECONDARY");
      
const button2 = new MessageButton()

      .setCustomId('myButton2')
.setLabel('كشف المباشرين')     .setEmoji("1128104446212182076")
      .setStyle("SECONDARY");



    const row = new MessageActionRow().addComponents(button , button1 , button2);



    await message.channel.send({ embeds: [embed], components: [row] });
message.delete()
  }
});


client.on('interactionCreate', async (interaction) => {

  if (!interaction.isButton()) return;



  const customId = interaction.customId;



  if (customId === 'myButton506') {
      
         
const Time = `${Math.floor(interaction.createdTimestamp / 1000)}`
const timeae = db.fetch(`tsgal_${interaction.user.id}`)
  if (timeae) {
      interaction.reply({content: `**انت مسجل دخول من قبل ${snow56} **`, ephemeral: true})
    return;
  }    
  
db.set(`tsgal_${interaction.user.id}`, Time)
db.add(`point_${interaction.user.id}`, 1)
    let points = db.get(`point_${interaction.user.id}`)
    

    if (!points) points = 0
    
interaction.reply({content: `**${snowpolsicon} - عزيزي العسكري : ${interaction.user}

${snow97} - تم تسجيل دخولك بنجاح\n[اضغط هنا للدخول الى الروم](https://discord.com/channels/912664756278689903/1153643458649665566)**`, ephemeral:true})

client.channels.cache.get(snow999).send (`**تسجيل دخول جديد !\n- العسكري : ${interaction.user}\n- قام بتسجيل الدخول بتاريخ <t:${Time}:F>\n- عدد نقاط العسكري : ${points} **`)
client.channels.cache.get(snow999).send(line)

  } 
})
  client.on('interactionCreate', async (interaction) => {

  if (!interaction.isButton()) return;
     const customId = interaction.customId;
 
    if (customId === 'myButton1') {
    
    let points = db.get(`point_${interaction.user.id}`)

const timeae = db.get(`tsgal_${interaction.user.id}`)
  if (!timeae) {
      interaction.reply({content: `**انت لم تسجل دخول من الاساس ${snow56} **`, ephemeral: true})
      return;
  }

interaction.reply({content: `**${snowpolsicon} - عزيزي العسكري : ${interaction.user}

${snow97} - تم تسجيل خروج بنجاح
${iconThanks} -  شكرا لك على جهدك المبذول في الدولة
- مدة تسجيل دخولك <t:${timeae}:R>**`, ephemeral : true})
client.channels.cache.get(snow999).send (`**تسجيل خروج جديد !
- العسكري : ${interaction.user}
- مدة تسجيل دخول العسكري <t:${timeae}:R>
- عدد نقاط العسكري : ${points} **`)
client.channels.cache.get(snow999).send(line)

db.delete(`tsgal_${interaction.user.id}`)
    
  } 
  });

client.on('interactionCreate', async (interaction) => {

  if (!interaction.isButton()) return;
  const customId = interaction.customId;

  if (customId === 'myButton2') {

 let data = db.all()
      .filter((data) => data[0].includes("tsgal"))
      .map((data) => [data[0].split("_")[1], parseInt(data[1].split(" ")[2])])
      .sort((a, b) => b[1] - a[1])
      .filter((data) => data[1] > 0)
      .map(async (data) => {
        let user = await client.users.fetch(data[0]);
        return {
          user: user ? (user.id === data[0] ? user.toString() : user.username) : "عضو لم استطيع العثور عليه",
          tsgal: data[1],
        };
      });

    let userData = await Promise.all(data);
    const embed = new MessageEmbed()
      .setColor(color)
      .setAuthor({ name: `Police | ${client.guilds.cache.first().name}`, iconURL: 'https://media.discordapp.net/attachments/1128102282345590785/1177600836797468712/pp770.png?ex=6573193e&is=6560a43e&hm=e41c0d6ad7a8f542ff232742ac3a3cdbbbd4ab1d790bb3ed072c21beb51b874e&'})
      .setDescription(userData.map((data) => `**${data.user}** | **__<t:${data.tsgal}:R>__**`).join("\n") || "**لايوجد مباشرين**");
    interaction.reply({ embeds: [embed], ephemeral: true });
  }

});
client.on('messageCreate', async (message) => {

  if (message.content === '#البلاغات') {
    
if (!message.member.roles.cache.some(role => targetRoleId.includes(role.id)))  return;

    const embed = new MessageEmbed()
      .setDescription(`**
> قائمة البلاغات | ${Listreports} 

- للبلاغ عن سرقة،خطف،قتل،الخ 
يرجى ضغط الزر

 ${Listerror} - يرجى كتابة النموذج بالكامل في حال المخالفة = تحذير اول

${snowpolsicon} - في حال استلام بلاغك من احد العسكر سيتم ابلاغك في الخاص**`)

      .setColor(color)


    const button = new MessageButton()

      .setCustomId('myButton')
.setLabel('بلاغ')
      .setStyle("SECONDARY");


    const row = new MessageActionRow().addComponents(button);



    await message.channel.send({ embeds: [embed], components: [row] });
message.delete()
  }

});



client.on('interactionCreate', async (interaction) => {

  if (!interaction.isButton()) return;



  const customId = interaction.customId;



  if (customId === 'myButton') {

    const addOwnerModal = new Modal()

      .setCustomId('myButton')

      .setTitle('قائمة البلاغات');

    const ownerIdInput = new TextInputComponent()

      .setCustomId('myButton')

      .setLabel('البلاغ')

      .setMaxLength(4000)

      .setStyle(`PARAGRAPH`)

      .setRequired(true);
    const were = new TextInputComponent()

      .setCustomId('were')

      .setLabel('مكان الحادثة')

      .setMaxLength(4000)

      .setStyle(`PARAGRAPH`)

      .setRequired(true);



    const modalRow = new MessageActionRow().addComponents(ownerIdInput);
    const modalRow1 = new MessageActionRow().addComponents(were);



    addOwnerModal.addComponents(modalRow, modalRow1);



    await interaction.showModal(addOwnerModal);

  } else if (customId === 'deleteButton') {
    
let points = db.get(`point_${interaction.user.id}`)

if (!points) points = 0

if (interaction.member.roles.cache.has(!astlim)) {
  await interaction.reply({ content: '**ليس لديك الإذن الكافي لاستلام البلاغ.**', ephemeral: true });
}

const title = interaction.message.embeds[0].title;
const regex = /بلاغ رقم : (\d+)/;
const match = title.match(regex);
const reportNumber = match ? match[1] : null;
    await 
   interaction.message.edit({ content: `**- تم استلام البلاغ بواسطة ${interaction.user}**`, components: [] });

db.add(`point_${interaction.user.id}`, 1)
    let steffDB = await db.get(`member_${reportNumber}`)

      let king = interaction.guild.members.cache.get(steffDB)
   try {
     king.send(`**${iconperson} - عزيزي العضو ${king}
${snowpolsicon} - تم استلام بلاغك من العسكري : ${interaction.user}
${snowpolspoints2} - يرجى التواصل مع العسكري لإكمال البلاغ**`)
} catch (error) {
     console.error(error)
   interaction.message.edit({ content: `**- تم استلام البلاغ بواسطة ${interaction.user}
- لم استطع توصيل الرسالة للمواطن : ${king} 
${reportNumber} ${match}**`,                     components: []});
   } 


client.channels.cache.get(snow999).send (`**استلام بلاغ جديد !
- العسكري : ${interaction.user}
- عدد نقاط العسكري : ${points}
- رقم البلاغ : ${reportNumber || 'غير متوفر'}**`)
    
 client.channels.cache.get(snow999).send(line)
   }
 });



client.on('interactionCreate', async (i) => {

  if (!i.isModalSubmit()) return;

  if (i.customId === 'myButton') {

    const myButton = i.fields.getTextInputValue('myButton');
        const were = i.fields.getTextInputValue('were');

    const user = i.user;


    let er = db.get('er') || 0;

    er++;

    db.set('er', er);

db.set(`member_${er}`, user.id)


    const mention = user.toString();






    const embed = new MessageEmbed()

      .setTitle(`**بلاغ رقم : ${er}**`)

      .setDescription(`**- البلاغ : ${myButton}
- مكان الحادثة : ${were}
صاحب البلاغ : ${mention}**`);



    const deleteButton = new MessageButton()

      .setCustomId('deleteButton')

      .setLabel('استلام البلاغ')

      .setStyle('DANGER');



    await client.channels.cache.get(mama).send({embeds: [embed], components: [new MessageActionRow().addComponents(deleteButton)] });

client.channels.cache.get(mama).send(line)

    await i.reply({ content: '**${snow97} - تم ارسال البلاغ بنجاح**', ephemeral: true });

  }

});

client.on('message',async snow => {

let user = snow.mentions.members.first()

  
  
let args = snow.content.split(' ')[2]
  
if(snow.content.startsWith(prefix + "نقطة+")){

if (!snow.member.roles.cache.some(role => staffpo.includes(role.id)))  return;
  let points = db.get(`point_${user.id}`);
if(!points) {

points = 0;
}  
if(!args) return snow.channel.send(`**__${Warning} |عـزيـزي الـمـسـؤول <@${snow.author.id}> ، يـرجـى كـتـابة الامـر بـالـشـكـل الـصـحـيـح 
مـثـال :
${prefix}نقطة+ <@${client.user.id}> 10 __**`)

if(!user) return snow.channel.send(`**__${Warning} |عـزيـزي الـمـسـؤول <@${snow.author.id}> ، يـرجـى كـتـابة الامـر بـالـشـكـل الـصـحـيـح 
مـثـال :
${prefix}ادارة+ <@${client.user.id}> 10 __**`)

if(isNaN(args)) return snow.channel.send(`**__${Warning} |عـزيـزي  الـمـسـؤول <@${snow.author.id}> ، هـذا لـيـس رقـمـاً__**`)
 
let embed = new Discord.MessageEmbed()

.setColor(color)
.setImage(line)
  .setThumbnail(snow.guild.iconURL())

.setDescription(`**__
${snowpolsicon} | عـزيـزي الـمـسـؤول :<@${snow.author.id}>

${snow97} | تمت عملية اضافة النقاط 

${snowpolspoints2} | عدد النقاط المضافة : \`${args}\`

${snowpolsicon} | العسكري الذي تمت اضافة النقاط اليه : <@${user.id}> 
__**`)

.setFooter(snow.author.username,snow.author.displayAvatarURL({dynamic:true}))
  
db.add(`point_${user.id}`, +args)
snow.channel.send({embeds: [embed]})
client.channels.cache.get(snow999).send (`**عملية اضافة نقاط جديدة !\n- المسؤول : ${snow.author}\n- قام باضافة نقاط للعسكري : ${user.id}\n- عدد النقاط المضافة : ${args}\n- نقاط العسكري الحاليه : ${points}**`)
client.channels.cache.get(snow999).send(line)


}
})

//chi5 kla d3s



client.on('message',async snow4 => {

let user = snow4.mentions.users.first() || snow4.author;

          let acRoom = snow4.guild.channels.cache.find(ch => ch.id === channelkshf)//ايدي روم لكشف النقاط
          if(!acRoom) return;
          if (snow4.channel.id != acRoom) return;
          if (snow4.channel.id == acRoom) {
  
let points = db.get(`point_${user.id}`);
            
if(snow4.content.startsWith(prefix +"كشف")){


if(!points) {

points = 0;
}

let embed = new Discord.MessageEmbed()

.setColor(color)
      .setThumbnail(snow4.guild.iconURL())
.setImage(line)
.setDescription(`**__${snowpolsicon} | عـزيـزي العسكري : <@${snow4.author.id}> 

${snowpolspoints2} | عدد النقاط : \`${points}\`

${snowpolsicon} | العسكري : ${user.username}__**`)

.setFooter(snow4.author.username,snow4.author.displayAvatarURL({dynamic:true}))
  
snow4.channel.send({embeds: [embed]})
}
          }
})

client.on('message', async message => {
    if(message.author.bot) return;
  if(!message.channel.guild) return;

          let acRoom = message.guild.channels.cache.find(ch => ch.id === channelkshf)//ايدي روم لكشف النقاط
          if(!acRoom) return;
          if (message.channel.id != acRoom) return;
          if (message.channel.id == acRoom) {
    if(message.content.startsWith(prefix + 'نقاطي')) {
        let points = await db.get(`point_${message.author.id}`);
           const embed = new Discord.MessageEmbed()
   

               
 .setDescription(` **__${snowpolsicon} | عزيزي العسكري : ${message.author}__**

 **__${snowpolspoints2} | ان عدد نقاطك هي : ${points || 0}__**

**__${iconThanks} | نتمنى لك يوماً سعيداً __**`)            .setFooter(`${message.guild.name}` ,      client.user.avatarURL())
   
      .setTimestamp()
              
      .setAuthor(`${message.guild.name}` , client.user.avatarURL())
                
      .setThumbnail(message.guild.iconURL())
                .setImage(line)
                
              .setColor(color);
            acRoom.send({embeds: [embed]})
    
    
    
    
    }
          } 
});



client.on('message',async snow1 => {

let user = snow1.mentions.members.first() || snow1.author;


let args = snow1.content.split(' ')[2]
  
if(snow1.content.startsWith(prefix + "نقطة-")){

if (!snow1.member.roles.cache.some(role => staffpo.includes(role.id))) return;
if(!args) return snow1.channel.send(`**__${Warning} |عـزيـزي الـمـسـؤول <@${snow1.author.id}> ، يـرجـى كـتـابة الامـر بـالـشـكـل الـصـحـيـح 
مـثـال :
${prefix}نقطة-
<@${client.user.id}> 10 __**`)

if(!user) return snow1.channel.send(`**__${Warning} |عـزيـزي الـمـسـؤول <@${snow1.author.id}> ، يـرجـى كـتـابة الامـر بـالـشـكـل الـصـحـيـح 
مـثـال :
${prefix}نقطة-
<@${client.user.id}> 10 __**`)

if(isNaN(args)) return snow1.channel.send(`**__${Warning} |عـزيـزي الـمـسـؤول <@${snow1.author.id}> ، هـذا لـيـس رقـمـاً__**`)

let embed = new Discord.MessageEmbed()

.setColor(color)

      .setThumbnail(snow1.guild.iconURL())
.setImage(line)

.setDescription(`**__${snowpolsicon} | عـزيـزي الـمـسـؤول :<@${snow1.author.id}>

${snow97} | تمت عملية ازالة النقاط 

${snowpolspoints2} | عدد النقاط التي تمت ازالتها : \`${args}\`

${snowpolsicon} | العسكري الذي تمت ازالة النقاط منه :<@${user.id}> __**`)
.setFooter(snow1.author.username,snow1.author.displayAvatarURL({dynamic:true}))
  
db.add(`point_${user.id}`, -args)

snow1.channel.send({embeds: [embed]})
client.channels.cache.get(snow999).send (`**عملية ازالة نقاط جديدة !\n- المسؤول : ${snow1.author}\n- قام بإزالة نقاط العسكري : ${user.id}\n- عدد النقاط المزالة : ${args}\n- نقاط العسكري الحاليه : ${points}**`)
client.channels.cache.get(snow999).send(line)

}
})
client.on('message', message => {
  if(message.content.startsWith(prefix + "تصفير-النقاط")){


if (!message.member.roles.cache.some(role => staffpo.includes(role.id))) return 
   message.guild.members.cache.forEach(member => {
     db.set(`point_${member.id}`, 0)
   })

let embed = new Discord.MessageEmbed()

    .setTitle(`**${message.guild.name}**`)
    .setColor(color)
    .setDescription(`**__ – عـزيـزي المـسـؤول .

- تـم تـصـفـيـر جـمـيـع النقاط مـن شرطة ${message.guild.name} بـالـكـامـل ${snow97} .

- مـع تـمـنـيـاتـنـا لـك بـالـتـوفـيـق__**`)
      .setImage(line)

message.channel.send({embeds: [embed]})
    client.channels.cache.get(snow999).send (`**عملية تصفير نقاط جديدة !\n- المسؤول : ${message.author}\n- قام بتصفير نقاط العسكر.**`)

  }
})

client.login("")//توكن بوتك

